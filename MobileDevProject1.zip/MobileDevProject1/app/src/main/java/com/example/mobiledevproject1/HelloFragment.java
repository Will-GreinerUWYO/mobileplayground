package com.example.mobiledevproject1;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;


import com.example.mobiledevproject1.databinding.FragmentHelloBinding;

public class HelloFragment extends Fragment{
    //TextView title;
    //EditText givenName;
    private FragmentHelloBinding fragmentHello;
    private HelloListener helloListener;

    public interface HelloListener {
        void onTextLogged(String text);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // You're not declaring fragmentHello here. I will send you a link, look at lines 27-41
        // Inflate the layout for this fragment
        fragmentHello = FragmentHelloBinding.inflate(inflater,container,false);
        fragmentHello.button2.setOnClickListener(this::onClick);

        fragmentHello.button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(requireContext(),"This is working", Toast.LENGTH_LONG).show();
                if (helloListener != null) {
                    String value = "Hello, World!";
                    if (fragmentHello.editTextText.getText().toString().compareTo("") != 0)
                        value = fragmentHello.editTextText.getText().toString();
                    fragmentHello.textView2.setText("Hello" + value);
                }
            }
        });
        return inflater.inflate(R.layout.fragment_hello, container, false);
    }


    public interface onClick {
        void onFragmentInteraction1(String Data);
    }

    public void displayName(View view) {

        //Log.v("");
    }

}
