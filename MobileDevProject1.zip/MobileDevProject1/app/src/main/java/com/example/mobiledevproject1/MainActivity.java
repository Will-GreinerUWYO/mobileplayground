package com.example.mobiledevproject1;

import android.os.Bundle;
import android.util.Log;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.mobiledevproject1.databinding.ActivityMainBinding;
// This will take an input from the HelloFragment as a Log to print out the name.
// It will also create and display the fragment.
public class MainActivity extends AppCompatActivity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    ActivityMainBinding binding = ActivityMainBinding.inflate(getLayoutInflater());
    setContentView(binding.getRoot());

    getSupportFragmentManager().beginTransaction().add(binding.main.getId(), new HelloFragment()).commit();

    }

    public void onEntry(String text){
        Log.v("Given Name Entry:", text);
    }
}